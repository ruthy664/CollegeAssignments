# Second Project Sentence Generator

import scipy
import numpy as np
import string
import pandas as pd
from collections import Counter
import en_core_web_md
import pickle

import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

nlp = en_core_web_md.load()

from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent

# Choose how many sentences
sentence_num = 10
# Choose the length of the sentence
words_per_sentence = 15
# Choose the first word of the sentence
first_word = 'The'
# Choose whether to keep the first one as first_word or soemthing similar
keep_exact = True
# Choose the file number
file_num = '00010203040506070809101112'
# Choose the number of clusters for that file
clusters = '500'

# Punctuation format
bs_punct = ['"', '#', '$', "'", '(',  '[', '{']
fs_punct = ['!', '%', ')', ',', ':', ';', ']', '}', "'s"]
ns_punct = ['-', '/', '@', '^']
# Include ? and ! in periods 

# Get files

# load lookup_dict
with open(f'{BASE_DIR}/transition_matrix/lookup_dict{file_num+clusters}.pkl', 'rb') as file:
    lookup_dict = pickle.load(file)

# load lookup_labels
with open(f'{BASE_DIR}/transition_matrix/lookup_labels{file_num+clusters}.pkl', 'rb') as file:
    lookup_labels = pickle.load(file)

# load 2gram
with open(f'{BASE_DIR}/transition_matrix/matrix2{file_num+clusters}.pkl', 'rb') as file:
    matrix2 = pickle.load(file)

N = len(lookup_dict)
M = N**2
states_list = [i for i in range(N)]

# load 3gram
matrix3 = scipy.sparse.load_npz(f'{BASE_DIR}/transition_matrix/matrix3{file_num+clusters}.npz')
matrix3 = scipy.sparse.csc_matrix(matrix3)

print(N,'clusters')

# Define Functions
def state_from_pair(index_pair):
    return index_pair[0]*N + index_pair[1]
def pair_from_state(state_ix):
    return (int(state_ix/N), state_ix % N)

def word_from_centroid(centroid):
    tup = lookup_dict.get(centroid)
    probs = tup[0]
    words = tup[1]
    next_word = np.random.choice(words, p=probs)
    return next_word

# two gram: centroid -> centroid is an index itself -> 

def two_gram(current_label):
    states_probs = matrix2[current_label]

    if states_probs.sum() == 0:
        return '.'

    next_label = np.random.choice(states_list, p=states_probs)
    # Find next word
    next_word = word_from_centroid(next_label)
    return (next_label, next_word)

# Make a second matrix for two-gram model in case of all zeros. 
# Try saving prob_state matrixes that get used when they are used. 
# For generating a period, go by row instead of collumn where the last word is now and 
# next word is period and current word is what ur choosing then the word. 

def get_next_word(prev_label, current_label):
    ix1, ix2 = states_list[prev_label], states_list[current_label]
    current_state = state_from_pair((ix1, ix2))
    
    next_states = [state_from_pair((ix2, k)) for k in range(N)]
    states_probs = matrix3[next_states, current_state].toarray().ravel()
    
    if states_probs.sum() == 0:
        return two_gram(current_label)
    else:
        states_probs = states_probs / states_probs.sum()
    
    next_label = np.random.choice(states_list, p=states_probs)
    next_word = word_from_centroid(next_label)
    return (next_label, next_word)

def find_label(word):
    token = nlp(word)[0]
    text = token.text
    label = lookup_labels.get(text)
    return label

def generate_sentence(first_word, total_words, keep_exact):
    first_word_label = find_label(first_word)
    ending_punct = '.'

    if not keep_exact:
        first_word = word_from_centroid(first_word_label)

    sentence = str(first_word)
    sentence = sentence[0].upper() + sentence[1:]

    period_label = find_label('.')
    
    next_word = get_next_word(period_label, first_word_label)
    sentence += ' ' + next_word[1]
    
    prev_word_label = period_label
    prev_word = '.'
    current_word_label = next_word[0]
    
    for i in range(total_words):
        next_word = get_next_word(prev_word_label, current_word_label)
        
        if next_word[1] == '.' or next_word[1] == '?' or next_word[1] == '!':
            ending_punct = next_word[1]
            break

        current_word = next_word[1]

        # if previous word wants only a backspace-> no front space for last word, so no back for current
        # if the current word wants only frontspace-> no backspace for the current word
        # if the current word is no space or the previous word is no space, no space 
        if (prev_word in bs_punct) or (current_word in fs_punct) or (prev_word in ns_punct) or (current_word in ns_punct):
            sentence += current_word
        else:
            sentence += ' ' + current_word
        
        prev_word = current_word
        prev_word_label = current_word_label
        current_word_label = next_word[0]

    # Get period
    sentence += ending_punct

    return sentence

# Generate the sentences
for i in range(sentence_num):
    print(generate_sentence(first_word, words_per_sentence, keep_exact),'\n')